from django.shortcuts import render, redirect, get_object_or_404
from .models import Alojamiento, Alquiler
from .forms import AlojamientoForm, AlquilerForm

# Create your views here.
