from django.apps import AppConfig


class AlojamientosConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'alojamientos_app'
