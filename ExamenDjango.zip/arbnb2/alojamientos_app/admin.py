from django.contrib import admin
from .models import Alojamiento, Alquiler

# Register your models here.

admin.site.register(Alojamiento)
admin.site.register(Alquiler)
